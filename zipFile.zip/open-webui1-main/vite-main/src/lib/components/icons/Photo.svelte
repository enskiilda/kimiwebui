<script lang="ts">
	export let className = 'size-4';
	export let strokeWidth = '1.5';
</script>

<svg
	xmlns="http://www.w3.org/2000/svg"
	fill="none"
	viewBox="0 0 24 24"
	stroke-width={strokeWidth}
	stroke="currentColor"
	class={className}
	aria-hidden="true"
	><path
		d="M21 7.6V20.4C21 20.7314 20.7314 21 20.4 21H7.6C7.26863 21 7 20.7314 7 20.4V7.6C7 7.26863 7.26863 7 7.6 7H20.4C20.7314 7 21 7.26863 21 7.6Z"
		stroke-linecap="round"
		stroke-linejoin="round"
	></path><path
		d="M18 4H4.6C4.26863 4 4 4.26863 4 4.6V18"
		stroke-linecap="round"
		stroke-linejoin="round"
	></path><path d="M7 16.8L12.4444 15L21 18" stroke-linecap="round" stroke-linejoin="round"
	></path><path
		d="M16.5 13C15.6716 13 15 12.3284 15 11.5C15 10.6716 15.6716 10 16.5 10C17.3284 10 18 10.6716 18 11.5C18 12.3284 17.3284 13 16.5 13Z"
		stroke-linecap="round"
		stroke-linejoin="round"
	></path></svg
>

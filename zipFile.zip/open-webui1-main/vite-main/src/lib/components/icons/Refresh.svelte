<script lang="ts">
	export let className = 'w-4 h-4';
	export let strokeWidth = '1.5';
</script>

<svg
	class={className}
	aria-hidden="true"
	xmlns="http://www.w3.org/2000/svg"
	stroke-width={strokeWidth}
	stroke="currentColor"
	fill="none"
	viewBox="0 0 24 24"
	><path
		d="M21.8883 13.5C21.1645 18.3113 17.013 22 12 22C6.47715 22 2 17.5228 2 12C2 6.47715 6.47715 2 12 2C16.1006 2 19.6248 4.46819 21.1679 8"
		stroke-linecap="round"
		stroke-linejoin="round"
	></path><path
		d="M17 8H21.4C21.7314 8 22 7.73137 22 7.4V3"
		stroke-linecap="round"
		stroke-linejoin="round"
	></path></svg
>

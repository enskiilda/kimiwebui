<script lang="ts">
	export let className = 'size-4';
	export let strokeWidth = '1.5';
</script>

<svg
	xmlns="http://www.w3.org/2000/svg"
	fill="none"
	viewBox="0 0 24 24"
	stroke-width={strokeWidth}
	stroke="currentColor"
	aria-hidden="true"
	class={className}
	><path
		d="M20 13V19C20 20.1046 19.1046 21 18 21H6C4.89543 21 4 20.1046 4 19V13"
		stroke-linecap="round"
		stroke-linejoin="round"
	></path><path
		d="M12 15V3M12 3L8.5 6.5M12 3L15.5 6.5"
		stroke-linecap="round"
		stroke-linejoin="round"
	></path></svg
>

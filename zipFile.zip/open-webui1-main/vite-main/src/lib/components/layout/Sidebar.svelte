<script lang="ts">
        import { toast } from 'svelte-sonner';
        import { v4 as uuidv4 } from 'uuid';

        import { goto } from '$app/navigation';
        import {
                user,
                chats,
                settings,
                chatId,
                tags,
                folders as _folders,
                showSidebar,
                showSearch,
                mobile,
                showArchivedChats,
                pinnedChats,
                scrollPaginationEnabled,
                currentChatPage,
                temporaryChatEnabled,
                channels,
                socket,
                config,
                isApp,
                models,
                selectedFolder,
                WEBUI_NAME
        } from '$lib/stores';
        import { onMount, getContext, tick, onDestroy } from 'svelte';

        const i18n = getContext('i18n');

        import {
                getChatList,
                getAllTags,
                getPinnedChatList,
                toggleChatPinnedStatusById,
                getChatById,
                updateChatFolderIdById,
                importChats
        } from '$lib/apis/chats';
        import { createNewFolder, getFolders, updateFolderParentIdById } from '$lib/apis/folders';

        import ArchivedChatsModal from './ArchivedChatsModal.svelte';
        import UserMenu from './Sidebar/UserMenu.svelte';
        import ChatItem from './Sidebar/ChatItem.svelte';
        import Spinner from '../common/Spinner.svelte';
        import Loader from '../common/Loader.svelte';
        import Folder from '../common/Folder.svelte';
        import Tooltip from '../common/Tooltip.svelte';
        import Folders from './Sidebar/Folders.svelte';
        import { getChannels, createNewChannel } from '$lib/apis/channels';
        import ChannelModal from './Sidebar/ChannelModal.svelte';
        import ChannelItem from './Sidebar/ChannelItem.svelte';
        import PencilSquare from '../icons/PencilSquare.svelte';
        import Search from '../icons/Search.svelte';
        import Settings from '../icons/Settings.svelte';
        import SearchModal from './SearchModal.svelte';
        import FolderModal from './Sidebar/Folders/FolderModal.svelte';
        import Sidebar from '../icons/Sidebar.svelte';
        import PinnedModelList from './Sidebar/PinnedModelList.svelte';
        import Note from '../icons/Note.svelte';
        import { slide } from 'svelte/transition';
        import HotkeyHint from '../common/HotkeyHint.svelte';
        import Avatar from '../common/Avatar.svelte';

        const BREAKPOINT = 768;

        let scrollTop = 0;

        let navElement;
        let shiftKey = false;

        let selectedChatId = null;
        let showCreateChannel = false;

        // Pagination variables
        let chatListLoading = false;
        let allChatsLoaded = false;

        let showCreateFolderModal = false;

        let folders = {};
        let folderRegistry = {};

        let newFolderId = null;

        $: if ($selectedFolder) {
                initFolders();
        }

        const initFolders = async () => {
                let folderList = [];
                try {
                        folderList = await getFolders(localStorage.token) || [];
                } catch (error) {
                }
                _folders.set(folderList.sort((a, b) => b.updated_at - a.updated_at));

                folders = {};

                // First pass: Initialize all folder entries
                for (const folder of folderList) {
                        // Ensure folder is added to folders with its data
                        folders[folder.id] = { ...(folders[folder.id] || {}), ...folder };

                        if (newFolderId && folder.id === newFolderId) {
                                folders[folder.id].new = true;
                                newFolderId = null;
                        }
                }

                // Second pass: Tie child folders to their parents
                for (const folder of folderList) {
                        if (folder.parent_id) {
                                // Ensure the parent folder is initialized if it doesn't exist
                                if (!folders[folder.parent_id]) {
                                        folders[folder.parent_id] = {}; // Create a placeholder if not already present
                                }

                                // Initialize childrenIds array if it doesn't exist and add the current folder id
                                folders[folder.parent_id].childrenIds = folders[folder.parent_id].childrenIds
                                        ? [...folders[folder.parent_id].childrenIds, folder.id]
                                        : [folder.id];

                                // Sort the children by updated_at field
                                folders[folder.parent_id].childrenIds.sort((a, b) => {
                                        return folders[b].updated_at - folders[a].updated_at;
                                });
                        }
                }
        };

        const createFolder = async ({ name, data }) => {
                name = name?.trim();
                if (!name) {
                        toast.error($i18n.t('Folder name cannot be empty.'));
                        return;
                }

                const rootFolders = Object.values(folders).filter((folder) => folder.parent_id === null);
                if (rootFolders.find((folder) => folder.name.toLowerCase() === name.toLowerCase())) {
                        // If a folder with the same name already exists, append a number to the name
                        let i = 1;
                        while (
                                rootFolders.find((folder) => folder.name.toLowerCase() === `${name} ${i}`.toLowerCase())
                        ) {
                                i++;
                        }

                        name = `${name} ${i}`;
                }

                // Add a dummy folder to the list to show the user that the folder is being created
                const tempId = uuidv4();
                folders = {
                        ...folders,
                        tempId: {
                                id: tempId,
                                name: name,
                                created_at: Date.now(),
                                updated_at: Date.now()
                        }
                };

                const res = await createNewFolder(localStorage.token, {
                        name,
                        data
                }).catch((error) => {
                        toast.error(`${error}`);
                        return null;
                });

                if (res) {
                        await initFolders();
                }
        };

        const initChannels = async () => {
                await channels.set(await getChannels(localStorage.token));
        };

        const initChatList = async () => {
                // Reset pagination variables
                currentChatPage.set(1);
                allChatsLoaded = false;
                scrollPaginationEnabled.set(false);

                initFolders();
                await Promise.all([
                        await (async () => {
                                const _tags = await getAllTags(localStorage.token);
                                tags.set(_tags);
                        })(),
                        await (async () => {
                                const _pinnedChats = await getPinnedChatList(localStorage.token);
                                pinnedChats.set(_pinnedChats);
                        })(),
                        await (async () => {
                                const _chats = await getChatList(localStorage.token, $currentChatPage);
                                await chats.set(_chats);
                        })()
                ]);

                // Enable pagination
                scrollPaginationEnabled.set(true);
        };

        const loadMoreChats = async () => {
                chatListLoading = true;

                currentChatPage.set($currentChatPage + 1);

                let newChatList = [];

                newChatList = await getChatList(localStorage.token, $currentChatPage);

                // once the bottom of the list has been reached (no results) there is no need to continue querying
                allChatsLoaded = newChatList.length === 0;
                // Deduplicate by ID when merging chats
                const existingIds = new Set(($chats ?? []).map(c => c.id));
                const uniqueNewChats = newChatList.filter(c => !existingIds.has(c.id));
                await chats.set([...($chats ? $chats : []), ...uniqueNewChats]);

                chatListLoading = false;
        };

        const importChatHandler = async (items, pinned = false, folderId = null) => {
                for (const item of items) {
                        if (item.chat) {
                                await importChats(localStorage.token, [
                                        {
                                                chat: item.chat,
                                                meta: item?.meta ?? {},
                                                pinned: pinned,
                                                folder_id: folderId,
                                                created_at: item?.created_at ?? null,
                                                updated_at: item?.updated_at ?? null
                                        }
                                ]);
                        }
                }

                initChatList();
        };

        const inputFilesHandler = async (files) => {
                for (const file of files) {
                        const reader = new FileReader();
                        reader.onload = async (e) => {
                                const content = e.target.result;

                                try {
                                        const chatItems = JSON.parse(content);
                                        importChatHandler(chatItems);
                                } catch {
                                        toast.error($i18n.t(`Invalid file format.`));
                                }
                        };

                        reader.readAsText(file);
                }
        };

        const tagEventHandler = async (type, tagName, chatId) => {
                if (type === 'delete') {
                        initChatList();
                } else if (type === 'add') {
                        initChatList();
                }
        };

        let draggedOver = false;

        const onDragOver = (e) => {
                e.preventDefault();

                // Check if a file is being draggedOver.
                if (e.dataTransfer?.types?.includes('Files')) {
                        draggedOver = true;
                } else {
                        draggedOver = false;
                }
        };

        const onDragLeave = () => {
                draggedOver = false;
        };

        const onDrop = async (e) => {
                e.preventDefault();

                // Perform file drop check and handle it accordingly
                if (e.dataTransfer?.files) {
                        const inputFiles = Array.from(e.dataTransfer?.files);

                        if (inputFiles && inputFiles.length > 0) {
                                inputFilesHandler(inputFiles); // Handle the dropped files
                        }
                }

                draggedOver = false; // Reset draggedOver status after drop
        };

        let touchstart;
        let touchend;

        function checkDirection() {
                const screenWidth = window.innerWidth;
                const swipeDistance = Math.abs(touchend.screenX - touchstart.screenX);
                if (touchstart.clientX < 40 && swipeDistance >= screenWidth / 8) {
                        if (touchend.screenX < touchstart.screenX) {
                                showSidebar.set(false);
                        }
                        if (touchend.screenX > touchstart.screenX) {
                                showSidebar.set(true);
                        }
                }
        }

        const onTouchStart = (e) => {
                touchstart = e.changedTouches[0];
        };

        const onTouchEnd = (e) => {
                touchend = e.changedTouches[0];
                checkDirection();
        };

        const onKeyDown = (e) => {
                if (e.key === 'Shift') {
                        shiftKey = true;
                }
        };

        const onKeyUp = (e) => {
                if (e.key === 'Shift') {
                        shiftKey = false;
                }
        };

        const onFocus = () => {};

        const onBlur = () => {
                shiftKey = false;
                selectedChatId = null;
        };

        let unsubscribers = [];
        onMount(async () => {
                await showSidebar.set(!$mobile ? localStorage.sidebar === 'true' : false);

                unsubscribers = [
                        mobile.subscribe((value) => {
                                if ($showSidebar && value) {
                                        showSidebar.set(false);
                                }

                                if ($showSidebar && !value) {
                                        const navElement = document.getElementsByTagName('nav')[0];
                                        if (navElement) {
                                                navElement.style['-webkit-app-region'] = 'drag';
                                        }
                                }
                        }),
                        showSidebar.subscribe(async (value) => {
                                localStorage.sidebar = value;

                                // nav element is not available on the first render
                                const navElement = document.getElementsByTagName('nav')[0];

                                if (navElement) {
                                        if ($mobile) {
                                                if (!value) {
                                                        navElement.style['-webkit-app-region'] = 'drag';
                                                } else {
                                                        navElement.style['-webkit-app-region'] = 'no-drag';
                                                }
                                        } else {
                                                navElement.style['-webkit-app-region'] = 'drag';
                                        }
                                }

                                if (value) {
                                        await initChannels();
                                        await initChatList();
                                }
                        })
                ];

                window.addEventListener('keydown', onKeyDown);
                window.addEventListener('keyup', onKeyUp);

                window.addEventListener('touchstart', onTouchStart);
                window.addEventListener('touchend', onTouchEnd);

                window.addEventListener('focus', onFocus);
                window.addEventListener('blur', onBlur);

                const dropZone = document.getElementById('sidebar');

                dropZone?.addEventListener('dragover', onDragOver);
                dropZone?.addEventListener('drop', onDrop);
                dropZone?.addEventListener('dragleave', onDragLeave);
        });

        onDestroy(() => {
                if (unsubscribers && unsubscribers.length > 0) {
                        unsubscribers.forEach((unsubscriber) => {
                                if (unsubscriber) {
                                        unsubscriber();
                                }
                        });
                }

                window.removeEventListener('keydown', onKeyDown);
                window.removeEventListener('keyup', onKeyUp);

                window.removeEventListener('touchstart', onTouchStart);
                window.removeEventListener('touchend', onTouchEnd);

                window.removeEventListener('focus', onFocus);
                window.removeEventListener('blur', onBlur);

                const dropZone = document.getElementById('sidebar');

                dropZone?.removeEventListener('dragover', onDragOver);
                dropZone?.removeEventListener('drop', onDrop);
                dropZone?.removeEventListener('dragleave', onDragLeave);
        });

        const newChatHandler = async () => {
                selectedChatId = null;
                selectedFolder.set(null);

                if ($user?.role !== 'admin' && $user?.permissions?.chat?.temporary_enforced) {
                        await temporaryChatEnabled.set(true);
                } else {
                        await temporaryChatEnabled.set(false);
                }

                setTimeout(() => {
                        if ($mobile) {
                                showSidebar.set(false);
                        }
                }, 0);
        };

        const itemClickHandler = async () => {
                selectedChatId = null;
                chatId.set('');

                if ($mobile) {
                        showSidebar.set(false);
                }

                await tick();
        };


        const isWindows = /Windows/i.test(navigator.userAgent);
</script>

<ArchivedChatsModal
        bind:show={$showArchivedChats}
        onUpdate={async () => {
                await initChatList();
        }}
/>

<ChannelModal
        bind:show={showCreateChannel}
        onSubmit={async ({ name, access_control }) => {
                name = name?.trim();
                if (!name) {
                        toast.error($i18n.t('Channel name cannot be empty.'));
                        return;
                }

                const res = await createNewChannel(localStorage.token, {
                        name: name,
                        access_control: access_control
                }).catch((error) => {
                        toast.error(`${error}`);
                        return null;
                });

                if (res) {
                        $socket.emit('join-channels', { auth: { token: $user?.token } });
                        await initChannels();
                        showCreateChannel = false;
                }
        }}
/>

<FolderModal
        bind:show={showCreateFolderModal}
        onSubmit={async (folder) => {
                await createFolder(folder);
                showCreateFolderModal = false;
        }}
/>

<!-- svelte-ignore a11y-no-static-element-interactions -->


<SearchModal
        bind:show={$showSearch}
        onClose={() => {
                if ($mobile) {
                        showSidebar.set(false);
                }
        }}
/>

<button
        id="sidebar-new-chat-button"
        class="hidden"
        on:click={() => {
                goto('/');
                newChatHandler();
        }}
/>

{#if $showSidebar || (!$mobile && !$showSidebar)}
        <div
                bind:this={navElement}
                id="sidebar"
                class="h-screen max-h-[100dvh] min-h-screen select-none flex-shrink-0 {$showSidebar ? 'w-[260px]' : 'w-[48px]'} {$showSidebar ? 'bg-[#f9f9f9] dark:bg-[#181818]' : 'bg-white dark:bg-[#212121]'} border-e border-[#f5f5f5] dark:border-[#2e2e2e] text-gray-900 dark:text-gray-200 text-sm overflow-x-hidden transition-all duration-300 ease-in-out
        "
                data-state={$showSidebar}
        >
                <div
                        class=" my-auto flex flex-col justify-between h-screen max-h-[100dvh] {$showSidebar ? 'w-[260px]' : 'w-[48px]'} overflow-x-hidden scrollbar-hidden z-50"
                >
                        <div
                                class="sidebar px-1.5 pt-2 pb-1.5 flex flex-col text-gray-600 dark:text-gray-400 sticky top-0 z-10"
                        >
                                <div class="flex items-center">
                                        <Tooltip
                                                content=""
                                                placement="right"
                                        >
                                                <button
                                                        class="flex items-center justify-center rounded-xl size-9 hover:bg-gray-100/50 dark:hover:bg-gray-850/50 transition no-drag-region shrink-0 {isWindows ? 'cursor-pointer' : $showSidebar ? 'cursor-[w-resize]' : 'cursor-[e-resize]'}"
                                                        on:click={() => {
                                                                showSidebar.set(!$showSidebar);
                                                        }}
                                                        aria-label={$showSidebar ? $i18n.t('Close Sidebar') : $i18n.t('Open Sidebar')}
                                                >
                                                        <Sidebar className="size-5" />
                                                </button>
                                        </Tooltip>
                                        {#if $showSidebar}
                                                <a href="/" class="flex flex-1 px-1.5" on:click={newChatHandler}>
                                                        <div
                                                                id="sidebar-webui-name"
                                                                class="self-center font-medium text-gray-850 dark:text-white font-primary"
                                                        >
                                                                {$WEBUI_NAME}
                                                        </div>
                                                </a>
                                        {/if}
                                </div>

                                <div
                                        class="{scrollTop > 0
                                                ? 'visible'
                                                : 'invisible'} sidebar-bg-gradient-to-b bg-linear-to-b from-gray-50 dark:from-gray-950 to-transparent from-50% pointer-events-none absolute inset-0 -z-10 -mb-6"
                                ></div>
                        </div>

                        <div class="px-1.5 pt-0.5 pb-1 flex flex-col gap-0 text-gray-600 dark:text-gray-400">
                                <Tooltip content="" placement="right">
                                        <a
                                                id="sidebar-new-chat-button"
                                                class="group flex items-center rounded-xl w-full hover:bg-gray-100 dark:hover:bg-gray-900 transition outline-none"
                                                href="/"
                                                draggable="false"
                                                on:click={newChatHandler}
                                                aria-label={$i18n.t('New Chat')}
                                        >
                                                <div class="flex items-center justify-center size-9 shrink-0">
                                                        <PencilSquare className="size-5" strokeWidth="2" />
                                                </div>
                                                {#if $showSidebar}
                                                        <div class="flex flex-1 items-center">
                                                                <div class="text-[15px] font-primary text-gray-800 dark:text-gray-200">{$i18n.t('New Chat')}</div>
                                                                <div class="flex-1"></div>
                                                                <HotkeyHint name="newChat" className="group-hover:visible invisible mr-2" />
                                                        </div>
                                                {/if}
                                        </a>
                                </Tooltip>

                                <Tooltip content="" placement="right">
                                        <button
                                                id="sidebar-search-button"
                                                class="group flex items-center rounded-xl w-full hover:bg-gray-100 dark:hover:bg-gray-900 transition outline-none text-left"
                                                on:click={() => {
                                                        showSearch.set(true);
                                                }}
                                                draggable="false"
                                                aria-label={$i18n.t('Search')}
                                        >
                                                <div class="flex items-center justify-center size-9 shrink-0">
                                                        <Search strokeWidth="2" className="size-5" />
                                                </div>
                                                {#if $showSidebar}
                                                        <div class="flex flex-1 items-center">
                                                                <div class="text-[15px] font-primary text-gray-800 dark:text-gray-200">{$i18n.t('Search')}</div>
                                                                <div class="flex-1"></div>
                                                                <HotkeyHint name="search" className="group-hover:visible invisible mr-2" />
                                                        </div>
                                                {/if}
                                        </button>
                                </Tooltip>

                                {#if ($config?.features?.enable_notes ?? false) && ($user?.role === 'admin' || ($user?.permissions?.features?.notes ?? true))}
                                        <Tooltip content="" placement="right">
                                                <a
                                                        id="sidebar-notes-button"
                                                        class="flex items-center rounded-xl w-full hover:bg-gray-100 dark:hover:bg-gray-900 transition"
                                                        href="/notes"
                                                        on:click={itemClickHandler}
                                                        draggable="false"
                                                        aria-label={$i18n.t('Notes')}
                                                >
                                                        <div class="flex items-center justify-center size-9 shrink-0">
                                                                <Note className="size-5" strokeWidth="2" />
                                                        </div>
                                                        {#if $showSidebar}
                                                                <div class="text-[15px] font-primary text-gray-800 dark:text-gray-200">{$i18n.t('Notes')}</div>
                                                        {/if}
                                                </a>
                                        </Tooltip>
                                {/if}

                                {#if $user?.role === 'admin' || $user?.permissions?.workspace?.models || $user?.permissions?.workspace?.knowledge || $user?.permissions?.workspace?.prompts || $user?.permissions?.workspace?.tools}
                                        <Tooltip content="" placement="right">
                                                <a
                                                        id="sidebar-workspace-button"
                                                        class="flex items-center rounded-xl w-full hover:bg-gray-100 dark:hover:bg-gray-900 transition"
                                                        href="/workspace"
                                                        on:click={itemClickHandler}
                                                        draggable="false"
                                                        aria-label={$i18n.t('Workspace')}
                                                >
                                                        <div class="flex items-center justify-center size-9 shrink-0">
                                                                <svg
                                                                        xmlns="http://www.w3.org/2000/svg"
                                                                        fill="none"
                                                                        viewBox="0 0 24 24"
                                                                        stroke-width="2"
                                                                        stroke="currentColor"
                                                                        class="size-5"
                                                                >
                                                                        <path
                                                                                stroke-linecap="round"
                                                                                stroke-linejoin="round"
                                                                                d="M13.5 16.875h3.375m0 0h3.375m-3.375 0V13.5m0 3.375v3.375M6 10.5h2.25a2.25 2.25 0 0 0 2.25-2.25V6a2.25 2.25 0 0 0-2.25-2.25H6A2.25 2.25 0 0 0 3.75 6v2.25A2.25 2.25 0 0 0 6 10.5Zm0 9.75h2.25A2.25 2.25 0 0 0 10.5 18v-2.25a2.25 2.25 0 0 0-2.25-2.25H6a2.25 2.25 0 0 0-2.25 2.25V18A2.25 2.25 0 0 0 6 20.25Zm9.75-9.75H18a2.25 2.25 0 0 0 2.25-2.25V6A2.25 2.25 0 0 0 18 3.75h-2.25A2.25 2.25 0 0 0 13.5 6v2.25a2.25 2.25 0 0 0 2.25 2.25Z"
                                                                        />
                                                                </svg>
                                                        </div>
                                                        {#if $showSidebar}
                                                                <div class="text-[15px] font-primary text-gray-800 dark:text-gray-200">{$i18n.t('Workspace')}</div>
                                                        {/if}
                                                </a>
                                        </Tooltip>
                                {/if}
                        </div>

                        <div
                                class="relative flex flex-col flex-1 overflow-y-auto scrollbar-hidden pb-3"
                                on:scroll={(e) => {
                                        if (e.target.scrollTop === 0) {
                                                scrollTop = 0;
                                        } else {
                                                scrollTop = e.target.scrollTop;
                                        }
                                }}
                        >
                                {#if $showSidebar}
                                        {#if ($models ?? []).length > 0 && (($settings?.pinnedModels ?? []).length > 0 || $config?.default_pinned_models)}
                                                <Folder
                                                        id="sidebar-models"
                                                        className="px-2 mt-0.5"
                                                        name={$i18n.t('Models')}
                                                        chevron={false}
                                                        dragAndDrop={false}
                                                >
                                                        <PinnedModelList bind:selectedChatId {shiftKey} />
                                                </Folder>
                                        {/if}

                                        {#if $config?.features?.enable_channels && ($user?.role === 'admin' || $channels.length > 0)}
                                        <Folder
                                                id="sidebar-channels"
                                                className="px-2 mt-0.5"
                                                name={$i18n.t('Channels')}
                                                chevron={false}
                                                dragAndDrop={false}
                                                onAdd={async () => {
                                                        if ($user?.role === 'admin') {
                                                                await tick();

                                                                setTimeout(() => {
                                                                        showCreateChannel = true;
                                                                }, 0);
                                                        }
                                                }}
                                                onAddLabel={$i18n.t('Create Channel')}
                                        >
                                                {#each $channels as channel}
                                                        <ChannelItem
                                                                {channel}
                                                                onUpdate={async () => {
                                                                        await initChannels();
                                                                }}
                                                        />
                                                {/each}
                                        </Folder>
                                {/if}

                                {#if folders}
                                        <Folder
                                                id="sidebar-folders"
                                                className="px-2 mt-0.5"
                                                name={$i18n.t('Folders')}
                                                chevron={false}
                                                onAdd={() => {
                                                        showCreateFolderModal = true;
                                                }}
                                                onAddLabel={$i18n.t('New Folder')}
                                                on:drop={async (e) => {
                                                        const { type, id, item } = e.detail;

                                                        if (type === 'folder') {
                                                                if (folders[id].parent_id === null) {
                                                                        return;
                                                                }

                                                                const res = await updateFolderParentIdById(localStorage.token, id, null).catch(
                                                                        (error) => {
                                                                                toast.error(`${error}`);
                                                                                return null;
                                                                        }
                                                                );

                                                                if (res) {
                                                                        await initFolders();
                                                                }
                                                        }
                                                }}
                                        >
                                                <Folders
                                                        bind:folderRegistry
                                                        {folders}
                                                        {shiftKey}
                                                        onDelete={(folderId) => {
                                                                selectedFolder.set(null);
                                                                initChatList();
                                                        }}
                                                        on:update={() => {
                                                                initChatList();
                                                        }}
                                                        on:import={(e) => {
                                                                const { folderId, items } = e.detail;
                                                                importChatHandler(items, false, folderId);
                                                        }}
                                                        on:change={async () => {
                                                                initChatList();
                                                        }}
                                                />
                                        </Folder>
                                {/if}

                                <Folder
                                        id="sidebar-chats"
                                        className="px-2 mt-0.5"
                                        name={$i18n.t('Chats')}
                                        chevron={false}
                                        on:change={async (e) => {
                                                selectedFolder.set(null);
                                        }}
                                        on:import={(e) => {
                                                importChatHandler(e.detail);
                                        }}
                                        on:drop={async (e) => {
                                                const { type, id, item } = e.detail;

                                                if (type === 'chat') {
                                                        let chat = await getChatById(localStorage.token, id).catch((error) => {
                                                                return null;
                                                        });
                                                        if (!chat && item) {
                                                                chat = await importChats(localStorage.token, [
                                                                        {
                                                                                chat: item.chat,
                                                                                meta: item?.meta ?? {},
                                                                                pinned: false,
                                                                                folder_id: null,
                                                                                created_at: item?.created_at ?? null,
                                                                                updated_at: item?.updated_at ?? null
                                                                        }
                                                                ]);
                                                        }

                                                        if (chat) {
                                                                if (chat.folder_id) {
                                                                        const res = await updateChatFolderIdById(localStorage.token, chat.id, null).catch(
                                                                                (error) => {
                                                                                        toast.error(`${error}`);
                                                                                        return null;
                                                                                }
                                                                        );

                                                                        folderRegistry[chat.folder_id]?.setFolderItems();
                                                                }

                                                                if (chat.pinned) {
                                                                        const res = await toggleChatPinnedStatusById(localStorage.token, chat.id);
                                                                }

                                                                initChatList();
                                                        }
                                                } else if (type === 'folder') {
                                                        if (folders[id].parent_id === null) {
                                                                return;
                                                        }

                                                        const res = await updateFolderParentIdById(localStorage.token, id, null).catch(
                                                                (error) => {
                                                                        toast.error(`${error}`);
                                                                        return null;
                                                                }
                                                        );

                                                        if (res) {
                                                                await initFolders();
                                                        }
                                                }
                                        }}
                                >
                                        {#if $pinnedChats.length > 0}
                                                <div class="mb-1">
                                                        <div class="flex flex-col space-y-1 rounded-xl">
                                                                <Folder
                                                                        id="sidebar-pinned-chats"
                                                                        buttonClassName=" text-gray-500"
                                                                        on:import={(e) => {
                                                                                importChatHandler(e.detail, true);
                                                                        }}
                                                                        on:drop={async (e) => {
                                                                                const { type, id, item } = e.detail;

                                                                                if (type === 'chat') {
                                                                                        let chat = await getChatById(localStorage.token, id).catch((error) => {
                                                                                                return null;
                                                                                        });
                                                                                        if (!chat && item) {
                                                                                                chat = await importChats(localStorage.token, [
                                                                                                        {
                                                                                                                chat: item.chat,
                                                                                                                meta: item?.meta ?? {},
                                                                                                                pinned: false,
                                                                                                                folder_id: null,
                                                                                                                created_at: item?.created_at ?? null,
                                                                                                                updated_at: item?.updated_at ?? null
                                                                                                        }
                                                                                                ]);
                                                                                        }

                                                                                        if (chat) {
                                                                                                if (chat.folder_id) {
                                                                                                        const res = await updateChatFolderIdById(
                                                                                                                localStorage.token,
                                                                                                                chat.id,
                                                                                                                null
                                                                                                        ).catch((error) => {
                                                                                                                toast.error(`${error}`);
                                                                                                                return null;
                                                                                                        });
                                                                                                }

                                                                                                if (!chat.pinned) {
                                                                                                        const res = await toggleChatPinnedStatusById(localStorage.token, chat.id);
                                                                                                }

                                                                                                initChatList();
                                                                                        }
                                                                                }
                                                                        }}
                                                                        name={$i18n.t('Pinned')}
                                                                >
                                                                        <div
                                                                                class="ml-3 pl-1 mt-[1px] flex flex-col overflow-y-auto scrollbar-hidden border-s border-gray-100 dark:border-gray-900 text-gray-900 dark:text-gray-200"
                                                                        >
                                                                                {#each $pinnedChats as chat, idx (`pinned-chat-${idx}-${chat?.id ?? 'unknown'}`)}
                                                                                        <ChatItem
                                                                                                className=""
                                                                                                id={chat.id}
                                                                                                title={chat.title}
                                                                                                {shiftKey}
                                                                                                selected={selectedChatId === chat.id}
                                                                                                on:select={() => {
                                                                                                        selectedChatId = chat.id;
                                                                                                }}
                                                                                                on:unselect={() => {
                                                                                                        selectedChatId = null;
                                                                                                }}
                                                                                                on:change={async () => {
                                                                                                        initChatList();
                                                                                                }}
                                                                                                on:tag={(e) => {
                                                                                                        const { type, name } = e.detail;
                                                                                                        tagEventHandler(type, name, chat.id);
                                                                                                }}
                                                                                        />
                                                                                {/each}
                                                                        </div>
                                                                </Folder>
                                                        </div>
                                                </div>
                                        {/if}

                                        <div class=" flex-1 flex flex-col overflow-y-auto scrollbar-hidden">
                                                <div class="pt-1.5">
                                                        {#if $chats}
                                                                {#each $chats as chat, idx (`chat-${idx}-${chat?.id ?? 'unknown'}`)}
                                                                        {#if idx === 0 || (idx > 0 && chat.time_range !== $chats[idx - 1].time_range)}
                                                                                <div
                                                                                        class="w-full pl-2.5 text-xs text-gray-500 dark:text-gray-500 font-medium {idx ===
                                                                                        0
                                                                                                ? ''
                                                                                                : 'pt-5'} pb-1.5"
                                                                                >
                                                                                        {$i18n.t(chat.time_range)}
                                                                                        <!-- localisation keys for time_range to be recognized from the i18next parser (so they don't get automatically removed):
                                                        {$i18n.t('Today')}
                                                        {$i18n.t('Yesterday')}
                                                        {$i18n.t('Previous 7 days')}
                                                        {$i18n.t('Previous 30 days')}
                                                        {$i18n.t('January')}
                                                        {$i18n.t('February')}
                                                        {$i18n.t('March')}
                                                        {$i18n.t('April')}
                                                        {$i18n.t('May')}
                                                        {$i18n.t('June')}
                                                        {$i18n.t('July')}
                                                        {$i18n.t('August')}
                                                        {$i18n.t('September')}
                                                        {$i18n.t('October')}
                                                        {$i18n.t('November')}
                                                        {$i18n.t('December')}
                                                        -->
                                                                                </div>
                                                                        {/if}

                                                                        <ChatItem
                                                                                className=""
                                                                                id={chat.id}
                                                                                title={chat.title}
                                                                                {shiftKey}
                                                                                selected={selectedChatId === chat.id}
                                                                                on:select={() => {
                                                                                        selectedChatId = chat.id;
                                                                                }}
                                                                                on:unselect={() => {
                                                                                        selectedChatId = null;
                                                                                }}
                                                                                on:change={async () => {
                                                                                        initChatList();
                                                                                }}
                                                                                on:tag={(e) => {
                                                                                        const { type, name } = e.detail;
                                                                                        tagEventHandler(type, name, chat.id);
                                                                                }}
                                                                        />
                                                                {/each}

                                                                {#if $scrollPaginationEnabled && !allChatsLoaded}
                                                                        <Loader
                                                                                on:visible={(e) => {
                                                                                        if (!chatListLoading) {
                                                                                                loadMoreChats();
                                                                                        }
                                                                                }}
                                                                        >
                                                                                <div
                                                                                        class="w-full flex justify-center py-1 text-xs animate-pulse items-center gap-2"
                                                                                >
                                                                                        <Spinner className=" size-4" />
                                                                                        <div class=" ">{$i18n.t('Loading...')}</div>
                                                                                </div>
                                                                        </Loader>
                                                                {/if}
                                                        {:else}
                                                                <div
                                                                        class="w-full flex justify-center py-1 text-xs animate-pulse items-center gap-2"
                                                                >
                                                                        <Spinner className=" size-4" />
                                                                        <div class=" ">{$i18n.t('Loading...')}</div>
                                                                </div>
                                                        {/if}
                                                </div>
                                        </div>
                                </Folder>
                                {/if}
                        </div>

                        <div class="px-1.5 pt-1.5 pb-2 sticky bottom-0 z-10 sidebar">
                                {#if $showSidebar}
                                        <div
                                                class="sidebar-bg-gradient-to-t bg-linear-to-t from-gray-50 dark:from-gray-950 to-transparent from-50% pointer-events-none absolute inset-0 -z-10 -mt-6"
                                        ></div>
                                {/if}
                                <div class="flex flex-col font-primary">
                                        {#if $user !== undefined && $user !== null}
                                                <UserMenu
                                                        role={$user?.role}
                                                        on:show={(e) => {
                                                                if (e.detail === 'archived-chat') {
                                                                        showArchivedChats.set(true);
                                                                }
                                                        }}
                                                >
                                                        <div
                                                                class="flex items-center rounded-2xl py-2 px-1 hover:bg-gray-100/50 dark:hover:bg-gray-900/50 transition {$showSidebar ? 'w-full' : ''}"
                                                        >
                                                                <div class="self-center shrink-0">
                                                                        <Avatar name={$user?.name} size="md" />
                                                                </div>
                                                                {#if $showSidebar}
                                                                        <div class="self-center font-medium ml-3">{$user?.name}</div>
                                                                {/if}
                                                        </div>
                                                </UserMenu>
                                        {/if}
                                </div>
                        </div>
                </div>
        </div>
{/if}
